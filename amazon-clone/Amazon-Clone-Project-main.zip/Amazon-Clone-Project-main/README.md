# Amazon-Clone-Project
Amazon clone using HTML and CSS
